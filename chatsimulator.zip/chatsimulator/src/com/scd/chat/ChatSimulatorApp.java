package com.scd.chat;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;

import com.scd.chat.ui.ChatWindowUI;
import com.scd.chat.model.User;
import com.scd.chat.pattern.builder.ChatSessionBuilder;
import com.scd.chat.model.ChatSession;
import com.scd.chat.util.Constants;

public class ChatSimulatorApp extends Application {
    
    @Override
    public void start(Stage primaryStage) {
        try {
            // Create main window layout
            BorderPane root = new BorderPane();
            root.setStyle("-fx-background-color: #f0f0f0;");
            
            // Top bar
            VBox topBar = createTopBar();
            
            // Center chat area with two chat windows
            HBox chatArea = createChatArea();
            
            // Bottom control panel
            VBox bottomPanel = createBottomPanel();
            
            root.setTop(topBar);
            root.setCenter(chatArea);
            root.setBottom(bottomPanel);
            
            Scene scene = new Scene(root,
                    Constants.WINDOW_WIDTH,
                    Constants.WINDOW_HEIGHT);

            // Optional: attach CSS if you created styles/application.css
            try {
                String css = getClass()
                        .getResource("/styles/application.css")
                        .toExternalForm();
                scene.getStylesheets().add(css);
            } catch (Exception ignored) {
                // If CSS not found, just run without it
            }

            primaryStage.setTitle(Constants.APP_NAME + " - SCD Lab Project");
            primaryStage.setScene(scene);
            primaryStage.show();
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    private VBox createTopBar() {
        VBox topBar = new VBox();
        topBar.setStyle("-fx-background-color: #2c3e50; -fx-text-fill: white;");
        topBar.setPadding(new Insets(15));
        topBar.setSpacing(5);
        
        Label title = new Label("Chat Simulator - Design Patterns Demo");
        title.setStyle("-fx-text-fill: white; -fx-font-size: 18px; -fx-font-weight: bold;");
        
        Label subtitle = new Label("Demonstrating: Singleton, Factory, Builder, Decorator, Observer");
        subtitle.setStyle("-fx-text-fill: #ecf0f1; -fx-font-size: 12px;");
        
        topBar.getChildren().addAll(title, subtitle);
        return topBar;
    }
    
    private HBox createChatArea() {
        HBox chatArea = new HBox(10);
        chatArea.setPadding(new Insets(10));
        chatArea.setStyle("-fx-background-color: white;");
        
        // Create sample users
        User alice = new User("user1", "Alice");
        User bob = new User("user2", "Bob");
        
        // Build chat session using Builder Pattern
        ChatSession session = new ChatSessionBuilder()
                .withSessionName("Team Discussion")
                .withCreator(alice)
                .addParticipant(bob)
                .withMaxParticipants(Constants.DEFAULT_MAX_PARTICIPANTS)
                .asPublic()
                .build();
        
        // Create two chat windows for same session
        ChatWindowUI window1 = new ChatWindowUI(session, alice);
        ChatWindowUI window2 = new ChatWindowUI(session, bob);
        
        // Put each ChatWindowUI into a ScrollPane so they resize nicely
        ScrollPane scroll1 = new ScrollPane(window1);
        scroll1.setFitToWidth(true);
        ScrollPane scroll2 = new ScrollPane(window2);
        scroll2.setFitToWidth(true);
        
        HBox.setHgrow(scroll1, Priority.ALWAYS);
        HBox.setHgrow(scroll2, Priority.ALWAYS);
        
        Separator separator = new Separator(Orientation.VERTICAL);
        
        chatArea.getChildren().addAll(scroll1, separator, scroll2);
        
        return chatArea;
    }
    
    private VBox createBottomPanel() {
        VBox bottomPanel = new VBox();
        bottomPanel.setStyle("-fx-background-color: #ecf0f1;");
        bottomPanel.setPadding(new Insets(10));
        bottomPanel.setSpacing(5);
        
        Label statusLabel = new Label("Status: Application Running | Sessions: 1");
        statusLabel.setStyle("-fx-font-size: 11px; -fx-text-fill: #34495e;");
        
        HBox controls = new HBox(10);
        controls.setPadding(new Insets(5, 0, 0, 0));
        
        Button clearLogs = new Button("Clear Logs");
        Button exportLogs = new Button("Export Logs");
        Button about = new Button("About");
        
        clearLogs.setStyle("-fx-padding: 5px 15px;");
        exportLogs.setStyle("-fx-padding: 5px 15px;");
        about.setStyle("-fx-padding: 5px 15px;");
        
        controls.getChildren().addAll(clearLogs, exportLogs, new Separator(Orientation.VERTICAL), about);
        
        bottomPanel.getChildren().addAll(statusLabel, controls);
        
        return bottomPanel;
    }
    
    public static void main(String[] args) {
        launch(args);
    }
}
