package com.scd.chat.ui;

import javafx.scene.control.TextArea;
import javafx.scene.layout.VBox;

/**
 * Simple message display component wrapping a TextArea.
 */
public class MessageDisplayArea extends VBox {

    private final TextArea textArea;

    public MessageDisplayArea() {
        this.textArea = new TextArea();
        this.textArea.setEditable(false);
        this.textArea.setWrapText(true);
        this.textArea.setPrefRowCount(12);
        this.textArea.setStyle("-fx-font-size: 12px;");

        getChildren().add(textArea);
    }

    public void appendLine(String line) {
        if (line == null) {
            return;
        }
        textArea.appendText(line + System.lineSeparator());
    }

    public void clear() {
        textArea.clear();
    }

    public TextArea getTextArea() {
        return textArea;
    }
}
