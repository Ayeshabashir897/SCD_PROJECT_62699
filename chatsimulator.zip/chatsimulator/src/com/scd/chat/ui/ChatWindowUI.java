package com.scd.chat.ui;

import com.scd.chat.model.ChatSession;
import com.scd.chat.model.Message;
import com.scd.chat.model.User;
import com.scd.chat.pattern.decorator.BoldMessageDecorator;
import com.scd.chat.pattern.decorator.ColorMessageDecorator;
import com.scd.chat.pattern.decorator.DecoratedMessage;
import com.scd.chat.pattern.decorator.ItalicMessageDecorator;
import com.scd.chat.pattern.decorator.PlainTextMessage;
import com.scd.chat.pattern.decorator.TimestampMessageDecorator;
import com.scd.chat.pattern.factory.IMessage;
import com.scd.chat.pattern.factory.MessageFactory;
import com.scd.chat.pattern.singleton.ChatEngine;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.Separator;
import javafx.scene.control.TextArea;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;

import java.time.format.DateTimeFormatter;

/**
 * Main chat window UI for a single user in a given ChatSession.
 */
public class ChatWindowUI extends BorderPane {

    private final ChatSession chatSession;
    private final User currentUser;

    private final MessageDisplayArea displayArea;
    private final TypingIndicator typingIndicator;
    private final TextArea inputArea;

    private final CheckBox boldCheck;
    private final CheckBox italicCheck;
    private final CheckBox timestampCheck;

    private final DateTimeFormatter timeFormatter =
            DateTimeFormatter.ofPattern("HH:mm:ss");

    public ChatWindowUI(ChatSession chatSession, User currentUser) {
        if (chatSession == null || currentUser == null) {
            throw new IllegalArgumentException("chatSession and currentUser cannot be null");
        }
        this.chatSession = chatSession;
        this.currentUser = currentUser;

        // Register session in ChatEngine singleton (optional but good for demo)
        ChatEngine.getInstance().registerSession(chatSession);

        // Layout
        setPadding(new Insets(10));

        // Top header
        setTop(createHeader());

        // Center: message display
        displayArea = new MessageDisplayArea();
        setCenter(displayArea);

        // Bottom: typing indicator, decorators, input + send button
        VBox bottomBox = new VBox(5);
        typingIndicator = new TypingIndicator();

        HBox decoratorBar = new HBox(10);
        decoratorBar.setPadding(new Insets(5));
        decoratorBar.setAlignment(Pos.CENTER_LEFT);
        Label decorLabel = new Label("Decorators:");
        decorLabel.setStyle("-fx-font-size: 10px;");

        boldCheck = new CheckBox("Bold");
        italicCheck = new CheckBox("Italic");
        timestampCheck = new CheckBox("Timestamp");
        timestampCheck.setSelected(true);

        decoratorBar.getChildren().addAll(
                decorLabel,
                new Separator(),
                boldCheck,
                italicCheck,
                timestampCheck
        );

        HBox inputBar = new HBox(10);
        inputBar.setAlignment(Pos.CENTER_LEFT);

        inputArea = new TextArea();
        inputArea.setPrefRowCount(3);
        inputArea.setWrapText(true);
        inputArea.setPromptText("Type a message and press Send...");

        Button sendButton = new Button("Send");
        sendButton.setOnAction(e -> sendMessage());

        HBox.setHgrow(inputArea, Priority.ALWAYS);
        inputBar.getChildren().addAll(inputArea, sendButton);

        bottomBox.getChildren().addAll(
                typingIndicator,
                decoratorBar,
                inputBar
        );

        setBottom(bottomBox);

        // Typing indicator events (simple version)
        inputArea.setOnKeyTyped(e -> typingIndicator.showTyping(currentUser.getNickname()));
        inputArea.setOnKeyReleased(e -> {
            if (inputArea.getText().isBlank()) {
                typingIndicator.clear();
            }
        });
    }

    private VBox createHeader() {
        VBox header = new VBox(2);
        header.setPadding(new Insets(5));
        header.setStyle("-fx-background-color: #3498db;");

        Label title = new Label("Session: " + chatSession.getSessionName());
        title.setStyle("-fx-text-fill: white; -fx-font-size: 13px; -fx-font-weight: bold;");

        Label userLabel = new Label("User: " + currentUser.getNickname());
        userLabel.setStyle("-fx-text-fill: #ecf0f1; -fx-font-size: 11px;");

        header.getChildren().addAll(title, userLabel);
        return header;
    }

    private void sendMessage() {
        String rawText = inputArea.getText().trim();
        if (rawText.isEmpty()) {
            return;
        }

        // Factory pattern: create message model
        IMessage factoryMessage = MessageFactory.createTextMessage(rawText, currentUser);

        // Adapt factory IMessage to your model.Message if needed
        Message modelMessage = new Message(
                factoryMessage.getId(),
                factoryMessage.getSender(),
                factoryMessage.getContent()
        );

        // Decorator pattern: apply selected decorators to text
        DecoratedMessage decorated = buildDecoratedMessage(rawText);

        // Display decorated text locally
        String timePart = factoryMessage.getTimestampInstant().atZone(java.time.ZoneId.systemDefault())
                .toLocalTime().format(timeFormatter);
        displayArea.appendLine("[" + timePart + "] " + currentUser.getNickname() + ": " + decorated.getText());

        // Route message via singleton ChatEngine (and add to session)
        ChatEngine.getInstance().routeMessage(chatSession.getSessionId(), modelMessage);

        // Clear input & typing indicator
        inputArea.clear();
        typingIndicator.clear();
    }

    private DecoratedMessage buildDecoratedMessage(String rawText) {
        DecoratedMessage msg = new PlainTextMessage(rawText);

        if (boldCheck.isSelected()) {
            msg = new BoldMessageDecorator(msg);
        }
        if (italicCheck.isSelected()) {
            msg = new ItalicMessageDecorator(msg);
        }
        if (timestampCheck.isSelected()) {
            msg = new TimestampMessageDecorator(msg);
        }

        // Example: you could also wrap in ColorMessageDecorator with a constant color
        msg = new ColorMessageDecorator(msg, "blue");

        return msg;
    }
}
