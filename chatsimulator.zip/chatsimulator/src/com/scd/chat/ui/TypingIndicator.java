package com.scd.chat.ui;

import javafx.scene.control.Label;
import javafx.scene.layout.HBox;

/**
 * Simple typing indicator component.
 */
public class TypingIndicator extends HBox {

    private final Label label;

    public TypingIndicator() {
        this.label = new Label("");
        this.label.setStyle("-fx-font-size: 10px; -fx-text-fill: #7f8c8d;");
        getChildren().add(label);
    }

    public void showTyping(String userName) {
        if (userName == null || userName.isBlank()) {
            clear();
        } else {
            label.setText(userName + " is typing...");
        }
    }

    public void clear() {
        label.setText("");
    }

    public Label getLabel() {
        return label;
    }
}
