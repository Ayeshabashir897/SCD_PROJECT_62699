package com.scd.chat.model;

import java.util.Objects;

/**
 * Represents a chat participant (user).
 */
public class User {

    private final String userId;
    private String nickname;
    private final long joinedTimeMillis;

    public User(String userId, String nickname) {
        if (userId == null || userId.isBlank()) {
            throw new IllegalArgumentException("userId cannot be null or blank");
        }
        if (nickname == null || nickname.isBlank()) {
            throw new IllegalArgumentException("nickname cannot be null or blank");
        }
        this.userId = userId;
        this.nickname = nickname;
        this.joinedTimeMillis = System.currentTimeMillis();
    }

    public String getUserId() {
        return userId;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        if (nickname == null || nickname.isBlank()) {
            throw new IllegalArgumentException("nickname cannot be null or blank");
        }
        this.nickname = nickname;
    }

    public long getJoinedTimeMillis() {
        return joinedTimeMillis;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof User)) return false;
        User other = (User) o;
        return userId.equals(other.userId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(userId);
    }

    @Override
    public String toString() {
        return "User{" +
                "userId='" + userId + '\'' +
                ", nickname='" + nickname + '\'' +
                '}';
    }
}
