package com.scd.chat.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Represents a chat session (conversation) between one or more users.
 * Creation with many options is done via ChatSessionBuilder in the builder package.
 */
public class ChatSession {

    private final String sessionId;
    private final String sessionName;
    private final User creator;
    private final boolean isPrivate;
    private final int maxParticipants;

    private final Set<User> participants;
    private final List<Message> messages;

    public ChatSession(String sessionId,
                       String sessionName,
                       User creator,
                       Set<User> initialParticipants,
                       boolean isPrivate,
                       int maxParticipants) {

        if (sessionId == null || sessionId.isBlank()) {
            throw new IllegalArgumentException("sessionId cannot be null or blank");
        }
        if (sessionName == null || sessionName.isBlank()) {
            throw new IllegalArgumentException("sessionName cannot be null or blank");
        }
        if (creator == null) {
            throw new IllegalArgumentException("creator cannot be null");
        }
        if (maxParticipants <= 0) {
            throw new IllegalArgumentException("maxParticipants must be > 0");
        }

        this.sessionId = sessionId;
        this.sessionName = sessionName;
        this.creator = creator;
        this.isPrivate = isPrivate;
        this.maxParticipants = maxParticipants;

        // Initialize participants
        this.participants = new HashSet<>();
        this.participants.add(creator); // creator is always a participant
        if (initialParticipants != null) {
            for (User user : initialParticipants) {
                if (this.participants.size() < maxParticipants) {
                    this.participants.add(user);
                }
            }
        }

        this.messages = new ArrayList<>();
    }

    public String getSessionId() {
        return sessionId;
    }

    public String getSessionName() {
        return sessionName;
    }

    public User getCreator() {
        return creator;
    }

    public boolean isPrivate() {
        return isPrivate;
    }

    public int getMaxParticipants() {
        return maxParticipants;
    }

    public Set<User> getParticipants() {
        return Collections.unmodifiableSet(participants);
    }

    public List<Message> getMessages() {
        return Collections.unmodifiableList(messages);
    }

    public boolean addParticipant(User user) {
        if (user == null) {
            throw new IllegalArgumentException("user cannot be null");
        }
        if (participants.size() >= maxParticipants) {
            return false;
        }
        return participants.add(user);
    }

    public boolean removeParticipant(User user) {
        if (user == null) {
            return false;
        }
        // Usually creator is not removed, but that rule is up to higher layers.
        return participants.remove(user);
    }

    /**
     * Adds a message to this session's history.
     * Actual routing, logging, and observer notifications are handled elsewhere (ChatEngine, observers).
     */
    public void addMessage(Message message) {
        if (message == null) {
            throw new IllegalArgumentException("message cannot be null");
        }
        messages.add(message);
    }

    @Override
    public String toString() {
        return "ChatSession{" +
                "sessionId='" + sessionId + '\'' +
                ", sessionName='" + sessionName + '\'' +
                ", creator=" + creator +
                ", isPrivate=" + isPrivate +
                ", maxParticipants=" + maxParticipants +
                ", participants=" + participants.size() +
                ", messages=" + messages.size() +
                '}';
    }
}
