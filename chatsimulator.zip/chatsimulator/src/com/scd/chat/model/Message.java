package com.scd.chat.model;

import java.time.Instant;
import java.util.Objects;

/**
 * Represents a single chat message.
 * Business logic such as styling and routing is handled by other layers.
 */
public class Message {

    private final String messageId;
    private final User sender;
    private final String content;
    private final long timestampMillis;

    public Message(String messageId, User sender, String content) {
        if (messageId == null || messageId.isBlank()) {
            throw new IllegalArgumentException("messageId cannot be null or blank");
        }
        if (sender == null) {
            throw new IllegalArgumentException("sender cannot be null");
        }
        if (content == null) {
            throw new IllegalArgumentException("content cannot be null");
        }
        this.messageId = messageId;
        this.sender = sender;
        this.content = content;
        this.timestampMillis = System.currentTimeMillis();
    }

    public String getMessageId() {
        return messageId;
    }

    public User getSender() {
        return sender;
    }

    public String getContent() {
        return content;
    }

    public long getTimestampMillis() {
        return timestampMillis;
    }

    public Instant getTimestampInstant() {
        return Instant.ofEpochMilli(timestampMillis);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Message)) return false;
        Message other = (Message) o;
        return messageId.equals(other.messageId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(messageId);
    }

    @Override
    public String toString() {
        return "Message{" +
                "messageId='" + messageId + '\'' +
                ", sender=" + sender +
                ", content='" + content + '\'' +
                ", timestampMillis=" + timestampMillis +
                '}';
    }
}
