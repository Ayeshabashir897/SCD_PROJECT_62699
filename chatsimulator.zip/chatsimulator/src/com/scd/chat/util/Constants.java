package com.scd.chat.util;

/**
 * Application-wide constants.
 */
public final class Constants {

    private Constants() {
        // Prevent instantiation
    }

    // Application info
    public static final String APP_NAME = "Simple Chat Simulator";
    public static final String APP_VERSION = "1.0.0";

    // Window defaults
    public static final int WINDOW_WIDTH = 1000;
    public static final int WINDOW_HEIGHT = 700;

    // Chat limits
    public static final int MAX_MESSAGE_LENGTH = 500;
    public static final int DEFAULT_MAX_PARTICIPANTS = 50;

    // UI colors (for CSS or inline styles)
    public static final String COLOR_PRIMARY = "#3498db";
    public static final String COLOR_BACKGROUND = "#ecf0f1";
    public static final String COLOR_TEXT_PRIMARY = "#2c3e50";
    public static final String COLOR_TEXT_SECONDARY = "#7f8c8d";

    // Logging
    public static final String DEFAULT_LOG_FILE = "chat_messages.log";

    // Date-time patterns
    public static final String LOG_TIME_PATTERN = "yyyy-MM-dd HH:mm:ss";
    public static final String UI_TIME_PATTERN = "HH:mm:ss";
}
