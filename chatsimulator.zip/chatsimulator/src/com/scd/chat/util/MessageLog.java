package com.scd.chat.util;

import com.scd.chat.model.Message;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

/**
 * Utility class to append chat messages to a log file.
 * This is independent from the in-memory logging in ChatEngine.
 */
public class MessageLog {

    private final String logFilePath;
    private final DateTimeFormatter timeFormatter;

    /**
     * Uses the default log file defined in Constants.
     */
    public MessageLog() {
        this(Constants.DEFAULT_LOG_FILE);
    }

    /**
     * Allows specifying a custom log file path.
     */
    public MessageLog(String logFilePath) {
        this.logFilePath = logFilePath;
        this.timeFormatter = DateTimeFormatter.ofPattern(Constants.LOG_TIME_PATTERN)
                .withZone(ZoneId.systemDefault());
    }

    /**
     * Appends a message entry to the log file.
     */
    public synchronized void logMessage(Message message) {
        if (message == null) {
            return;
        }

        String timestamp = timeFormatter.format(
                Instant.ofEpochMilli(message.getTimestampMillis())
        );

        String line = String.format(
                "[%s] %s (%s): %s",
                timestamp,
                message.getSender().getNickname(),
                message.getSender().getUserId(),
                message.getContent()
        );

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(logFilePath, true))) {
            writer.write(line);
            writer.newLine();
        } catch (IOException e) {
            // For a lab project, simple printStackTrace is acceptable
            e.printStackTrace();
        }
    }

    /**
     * Writes a generic info line to the log (no Message object).
     */
    public synchronized void logInfo(String info) {
        if (info == null) {
            return;
        }

        String timestamp = timeFormatter.format(Instant.now());
        String line = String.format("[%s] INFO: %s", timestamp, info);

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(logFilePath, true))) {
            writer.write(line);
            writer.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
