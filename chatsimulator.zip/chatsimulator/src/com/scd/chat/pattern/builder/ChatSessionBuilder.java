package com.scd.chat.pattern.builder;

import com.scd.chat.model.ChatSession;
import com.scd.chat.model.User;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/**
 * Builder for ChatSession objects.
 * Demonstrates the Builder Pattern for constructing complex objects step-by-step.
 */
public class ChatSessionBuilder {

    // Required fields
    private String sessionId;
    private String sessionName;
    private User creator;

    // Optional fields with defaults
    private final Set<User> participants = new HashSet<>();
    private boolean isPrivate = false;
    private int maxParticipants = 50;

    public ChatSessionBuilder() {
        // default constructor
    }

    /**
     * Sets the session id.
     * If not provided, a random id will be generated in build().
     */
    public ChatSessionBuilder withSessionId(String sessionId) {
        this.sessionId = sessionId;
        return this;
    }

    /**
     * Sets a human-readable session name (e.g., "Team Chat").
     */
    public ChatSessionBuilder withSessionName(String sessionName) {
        this.sessionName = sessionName;
        return this;
    }

    /**
     * Sets the creator of the session and automatically adds them as a participant.
     */
    public ChatSessionBuilder withCreator(User creator) {
        this.creator = creator;
        if (creator != null) {
            this.participants.add(creator);
        }
        return this;
    }

    /**
     * Adds a single participant.
     */
    public ChatSessionBuilder addParticipant(User user) {
        if (user != null) {
            this.participants.add(user);
        }
        return this;
    }

    /**
     * Adds multiple participants.
     */
    public ChatSessionBuilder addParticipants(User... users) {
        if (users != null) {
            for (User user : users) {
                addParticipant(user);
            }
        }
        return this;
    }

    /**
     * Marks this session as private.
     */
    public ChatSessionBuilder asPrivate() {
        this.isPrivate = true;
        return this;
    }

    /**
     * Marks this session as public.
     */
    public ChatSessionBuilder asPublic() {
        this.isPrivate = false;
        return this;
    }

    /**
     * Sets the maximum number of participants allowed in this session.
     */
    public ChatSessionBuilder withMaxParticipants(int maxParticipants) {
        if (maxParticipants <= 0) {
            throw new IllegalArgumentException("maxParticipants must be > 0");
        }
        this.maxParticipants = maxParticipants;
        return this;
    }

    /**
     * Validates fields and constructs the ChatSession (product).
     */
    public ChatSession build() {
        // Generate a random id if none was provided
        if (sessionId == null || sessionId.isBlank()) {
            sessionId = "session-" + UUID.randomUUID();
        }

        if (sessionName == null || sessionName.isBlank()) {
            throw new IllegalStateException("sessionName is required");
        }

        if (creator == null) {
            throw new IllegalStateException("creator is required");
        }

        // Ensure creator is in participants
        participants.add(creator);

        return new ChatSession(
                sessionId,
                sessionName,
                creator,
                participants,
                isPrivate,
                maxParticipants
        );
    }
}
