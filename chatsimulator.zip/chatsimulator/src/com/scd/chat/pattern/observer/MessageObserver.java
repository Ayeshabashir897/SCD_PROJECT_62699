package com.scd.chat.pattern.observer;

import com.scd.chat.model.Message;

/**
 * Observer interface for UI or other components that
 * want to be notified about message and typing events.
 */
public interface MessageObserver {

    /**
     * Called when a new message is delivered to a session.
     */
    void onMessageReceived(Message message);

    /**
     * Called when a user starts typing in a session.
     */
    void onTypingStarted(String userName);

    /**
     * Called when a user stops typing in a session.
     */
    void onTypingEnded(String userName);
}
