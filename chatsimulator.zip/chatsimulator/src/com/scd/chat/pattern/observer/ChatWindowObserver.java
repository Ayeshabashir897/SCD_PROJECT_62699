package com.scd.chat.pattern.observer;

import com.scd.chat.model.Message;

/**
 * Concrete observer representing a chat window in the UI.
 * In a real JavaFX application, this would hold references
 * to UI controls (TextArea, ListView, labels, etc.) and update them.
 * Here it just prints to the console to clearly demonstrate the pattern.
 */
public class ChatWindowObserver implements MessageObserver {

    private final String windowId;   // e.g. "Alice-Window", "Bob-Window"

    public ChatWindowObserver(String windowId) {
        if (windowId == null || windowId.isBlank()) {
            throw new IllegalArgumentException("windowId cannot be null or blank");
        }
        this.windowId = windowId;
    }

    public String getWindowId() {
        return windowId;
    }

    @Override
    public void onMessageReceived(Message message) {
        // In real code, update UI TextArea/ListView here.
        System.out.println("[" + windowId + "] New message from "
                + message.getSender().getNickname() + ": "
                + message.getContent());
    }

    @Override
    public void onTypingStarted(String userName) {
        // In real code, show typing indicator label.
        System.out.println("[" + windowId + "] " + userName + " is typing...");
    }

    @Override
    public void onTypingEnded(String userName) {
        // In real code, hide typing indicator label.
        System.out.println("[" + windowId + "] " + userName + " stopped typing.");
    }
}
