package com.scd.chat.pattern.observer;

import com.scd.chat.model.Message;

/**
 * A simpler listener interface focused only on message events.
 * You can use this for logging or non-UI components.
 */
public interface MessageListener {

    /**
     * Called when a new message is available.
     */
    void onNewMessage(Message message);
}
