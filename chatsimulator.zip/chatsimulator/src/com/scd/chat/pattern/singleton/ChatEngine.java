package com.scd.chat.pattern.singleton;

import com.scd.chat.model.ChatSession;
import com.scd.chat.model.Message;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

/**
 * ChatEngine (Singleton)
 *
 * - Single global instance for the whole application.
 * - Manages chat sessions and central message log.
 * - Provides APIs for creating sessions and routing messages.
 */
public class ChatEngine {

    // Static reference to the single instance (lazy initialization)
    private static volatile ChatEngine instance;

    // In-memory storage
    private final Map<String, ChatSession> activeSessions;
    private final List<Message> messageLog;

    // Utility
    private final DateTimeFormatter timeFormatter;

    // Private constructor to prevent external instantiation
    private ChatEngine() {
        this.activeSessions = new HashMap<>();
        this.messageLog = new ArrayList<>();
        this.timeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    }

    /**
     * Returns the single instance of ChatEngine.
     * Uses double-checked locking for thread safety and performance.
     */
    public static ChatEngine getInstance() {
        if (instance == null) { // first check (no locking)
            synchronized (ChatEngine.class) {
                if (instance == null) { // second check (with locking)
                    instance = new ChatEngine();
                }
            }
        }
        return instance;
    }

    /**
     * Registers a chat session in the engine.
     * If a session with the same id already exists, it is replaced.
     */
    public synchronized void registerSession(ChatSession session) {
        if (session == null) {
            throw new IllegalArgumentException("session cannot be null");
        }
        activeSessions.put(session.getSessionId(), session);
        System.out.println("[ChatEngine] Registered session: " + session.getSessionId());
    }

    /**
     * Returns a ChatSession by id, or null if not found.
     */
    public synchronized ChatSession getSession(String sessionId) {
        if (sessionId == null) return null;
        return activeSessions.get(sessionId);
    }

    /**
     * Returns an unmodifiable view of all active sessions.
     */
    public synchronized Collection<ChatSession> getAllSessions() {
        return Collections.unmodifiableCollection(activeSessions.values());
    }

    /**
     * Central routing method.
     * - Adds the message to the given session.
     * - Logs the message in the global message log.
     * Higher layers (observer, UI) can listen on the session to update views.
     */
    public synchronized void routeMessage(String sessionId, Message message) {
        if (sessionId == null || message == null) {
            throw new IllegalArgumentException("sessionId and message cannot be null");
        }

        ChatSession session = activeSessions.get(sessionId);
        if (session == null) {
            System.err.println("[ChatEngine] No session found with id: " + sessionId);
            return;
        }

        // Add to session history
        session.addMessage(message);

        // Add to global log
        logMessage(message);

        // Here you would typically also trigger observer notifications
        // (e.g., session.notifyMessageReceived(message)) if ChatSession is observable.
    }

    /**
     * Adds a message to the global message log.
     */
    public synchronized void logMessage(Message message) {
        messageLog.add(message);
        String time = LocalDateTime.now().format(timeFormatter);
        System
