package com.scd.chat.pattern.factory;

import com.scd.chat.model.User;

import java.util.UUID;

/**
 * Factory class responsible for creating IMessage instances.
 * Client code does not use 'new SimpleMessage(...)' directly.
 */
public class MessageFactory {

    private MessageFactory() {
        // Prevent instantiation; all methods are static.
    }

    /**
     * Creates a TEXT message from a user.
     */
    public static IMessage createTextMessage(String content, User sender) {
        return createMessage(content, sender, MessageType.TEXT);
    }

    /**
     * Creates a SYSTEM message (e.g., "User joined", "User left").
     * The sender is a synthetic SYSTEM user.
     */
    public static IMessage createSystemMessage(String content) {
        User systemUser = new User("SYSTEM", "System");
        return createMessage(content, systemUser, MessageType.SYSTEM);
    }

    /**
     * Creates a NOTIFICATION message (e.g., mentions, alerts).
     */
    public static IMessage createNotificationMessage(String content, User sender) {
        return createMessage(content, sender, MessageType.NOTIFICATION);
    }

    /**
     * Generic factory method used internally by the specific methods.
     */
    public static IMessage createMessage(String content, User sender, MessageType type) {
        String id = generateMessageId(type);
        return new SimpleMessage(id, sender, content, type);
    }

    /**
     * Utility to generate a unique message id.
     */
    private static String generateMessageId(MessageType type) {
        return type.name().toLowerCase() + "-" + UUID.randomUUID();
    }
}
