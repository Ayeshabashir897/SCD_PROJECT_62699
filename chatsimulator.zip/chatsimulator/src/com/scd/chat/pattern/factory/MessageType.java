package com.scd.chat.pattern.factory;

/**
 * Represents different types of messages that can be created by the factory.
 */
public enum MessageType {
    TEXT,
    SYSTEM,
    NOTIFICATION
}
