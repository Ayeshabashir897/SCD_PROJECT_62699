package com.scd.chat.pattern.factory;

import com.scd.chat.model.User;

import java.time.Instant;
import java.util.Objects;

/**
 * Concrete implementation of IMessage created by the MessageFactory.
 */
public class SimpleMessage implements IMessage {

    private final String id;
    private final User sender;
    private final String content;
    private final MessageType type;
    private final long timestampMillis;

    public SimpleMessage(String id, User sender, String content, MessageType type) {
        if (id == null || id.isBlank()) {
            throw new IllegalArgumentException("id cannot be null or blank");
        }
        if (sender == null) {
            throw new IllegalArgumentException("sender cannot be null");
        }
        if (content == null) {
            throw new IllegalArgumentException("content cannot be null");
        }
        if (type == null) {
            throw new IllegalArgumentException("type cannot be null");
        }

        this.id = id;
        this.sender = sender;
        this.content = content;
        this.type = type;
        this.timestampMillis = System.currentTimeMillis();
    }

    @Override
    public String getId() {
        return id;
    }

    @Override
    public User getSender() {
        return sender;
    }

    @Override
    public String getContent() {
        return content;
    }

    @Override
    public MessageType getType() {
        return type;
    }

    @Override
    public long getTimestampMillis() {
        return timestampMillis;
    }

    public Instant getTimestampInstant() {
        return Instant.ofEpochMilli(timestampMillis);
    }

    @Override
    public String toString() {
        return "SimpleMessage{" +
                "id='" + id + '\'' +
                ", sender=" + sender +
                ", content='" + content + '\'' +
                ", type=" + type +
                ", timestampMillis=" + timestampMillis +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof SimpleMessage)) return false;
        SimpleMessage that = (SimpleMessage) o;
        return id.equals(that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}
