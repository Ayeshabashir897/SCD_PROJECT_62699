package com.scd.chat.pattern.factory;

import com.scd.chat.model.User;

/**
 * Abstraction for messages created by the MessageFactory.
 * This helps to decouple client code from concrete implementations.
 */
public interface IMessage {

    String getId();

    User getSender();

    String getContent();

    MessageType getType();

    long getTimestampMillis();
}
