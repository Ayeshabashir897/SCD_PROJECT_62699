package com.scd.chat.pattern.decorator;

/**
 * Component interface for decorated messages.
 * Decorators will wrap an instance of this type.
 */
public interface DecoratedMessage {
    String getText();
}

/**
 * Base abstract decorator that wraps another DecoratedMessage.
 */
public abstract class MessageDecorator implements DecoratedMessage {

    protected final DecoratedMessage inner;

    protected MessageDecorator(DecoratedMessage inner) {
        if (inner == null) {
            throw new IllegalArgumentException("inner message cannot be null");
        }
        this.inner = inner;
    }

    @Override
    public String getText() {
        return inner.getText();
    }
}
