package com.scd.chat.pattern.decorator;

/**
 * Adds bold styling to the message text.
 * How you interpret the markers (e.g., **text**) is up to the UI layer.
 */
public class BoldMessageDecorator extends MessageDecorator {

    public BoldMessageDecorator(DecoratedMessage inner) {
        super(inner);
    }

    @Override
    public String getText() {
        // Simple representation: wrap with ** **
        return "**" + inner.getText() + "**";
    }
}
