package com.scd.chat.pattern.decorator;

/**
 * Adds a color hint to the message text.
 * The UI can parse this and apply actual color via CSS.
 */
public class ColorMessageDecorator extends MessageDecorator {

    private final String colorName;

    public ColorMessageDecorator(DecoratedMessage inner, String colorName) {
        super(inner);
        this.colorName = (colorName == null || colorName.isBlank())
                ? "default"
                : colorName.toLowerCase();
    }

    @Override
    public String getText() {
        // Simple tag format: [color=red]text[/color]
        return "[color=" + colorName + "]" + inner.getText() + "[/color]";
    }
}
