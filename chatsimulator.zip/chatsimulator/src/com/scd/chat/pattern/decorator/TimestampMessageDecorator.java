package com.scd.chat.pattern.decorator;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

/**
 * Adds a timestamp prefix to the message text.
 */
public class TimestampMessageDecorator extends MessageDecorator {

    private final String formattedTime;

    public TimestampMessageDecorator(DecoratedMessage inner) {
        super(inner);
        LocalTime now = LocalTime.now();
        this.formattedTime = now.format(DateTimeFormatter.ofPattern("HH:mm:ss"));
    }

    @Override
    public String getText() {
        return "[" + formattedTime + "] " + inner.getText();
    }
}
