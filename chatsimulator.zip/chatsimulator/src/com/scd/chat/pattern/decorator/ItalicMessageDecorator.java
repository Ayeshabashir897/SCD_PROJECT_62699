package com.scd.chat.pattern.decorator;

/**
 * Adds italic styling to the message text.
 */
public class ItalicMessageDecorator extends MessageDecorator {

    public ItalicMessageDecorator(DecoratedMessage inner) {
        super(inner);
    }

    @Override
    public String getText() {
        // Simple representation: wrap with * *
        return "*" + inner.getText() + "*";
    }
}
